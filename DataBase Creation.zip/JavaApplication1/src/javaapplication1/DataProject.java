package javaapplication1;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author - Sushanth
 */

interface constants
{
    static int num = 32561;
}
class Data {
    
    public int age;
    public int fnlwgt;
    public String workclass;
    public String education;
    public int edu_num;
    public String martialstatus;
    public String occupation;
    public String relationship;
    public String race;
    public String sex;
    public int capital_gain;
    public int capital_loss;
    public int hoursperweek;
    public String country;
    public String incomeclass;
     public int agech;
     public int educh;
     public int cgainch;
     public int clossch;
     public int hpwch;
}

class ReadCSV implements constants {
    
        
  public static void readCVS(Data [] obj){
    
    String csvFile = "C:\\Users\\My PC\\Desktop\\project 101\\adult1.csv";
    BufferedReader br = null;
    String line = "";
    String csvSplitBy = ",";
    int i=0;
    for(int k=0;k<num;k++)
        obj[k]=new Data();

	try {

		br = new BufferedReader(new FileReader(csvFile));
                line = br.readLine();
		while (i<num) {
                    line = br.readLine();
		String[] DataSet = line.split(csvSplitBy);
                obj[i].age = Integer.parseInt(DataSet[0]);
                obj[i].fnlwgt = Integer.parseInt(DataSet[2]);
                obj[i].workclass=DataSet[1];
                obj[i].education=DataSet[3];
                obj[i].edu_num=Integer.parseInt(DataSet[4]);
                obj[i].martialstatus=DataSet[5];
                obj[i].occupation=DataSet[6];
                obj[i].relationship=DataSet[7];
                obj[i].race=DataSet[8];
                obj[i].sex=DataSet[9];
                obj[i].capital_gain=Integer.parseInt(DataSet[10]);
                obj[i].capital_loss=Integer.parseInt(DataSet[11]);
                obj[i].hoursperweek=Integer.parseInt(DataSet[12]);
                obj[i].country=DataSet[13];
                obj[i].incomeclass=DataSet[14];
                i++;

                }

	} 
        catch (FileNotFoundException e) {
	} catch (IOException e) {
	} finally {
		if (br != null) {
			try {
				br.close();
			} catch (IOException e) {
			}
		}
//        for(int j=0;j<10;j++)
//            System.out.println(obj[j].age+obj[j].workclass);
	System.out.println("File Reading Done \nRead "+num+" records");
  }
  
  }
}

class InfoGain implements constants
{
//    static int num = 20;
    public static double log2(double no)
    {
        if(no == 0.0)
            return 0;
        double a;
        a = Math.log(no)/Math.log(2d);
        return a;
    }
    
    public void gain(Data [] obj){
        
        ArrayList alist = new ArrayList();
        int [] g50 = new int[130];
        int [] total = new int[130];
        int temp=0;
        int n=0;
        int size = 0;
        String str = null;
        String head = null;
        double olde;
        double newe = 0.0d;
        
        
        int count=0;
        
        for(int i=0;i<num;i++)
        {
            if(obj[i].incomeclass.equals(">50K"))
                count++;
        }
        
        int left = num-count;
        olde = - (((double)count/num)*log2((double)count/num) + ((double)left/num)*log2((double)left/num));
        System.out.println("Total gain = "+ olde);
        
        for(int i=0;i<13;i++)
        {
            newe = 0.0;
            for(int f=0;f<130;f++)
            {
                g50[f]=0;
                total[f]=0;
            }
        
        for(int j=0;j<num;j++)
        {
            temp =0;
            switch (i) {
                case 0:
                    head = "workclass";
                    str = obj[j].workclass;
                    break;
                case 1:
                    head = "education";
                    str = obj[j].education;
                    break;
                case 2:
                    head = "martial-status";
                    str = obj[j].martialstatus;
                    break;
                case 3:
                    head = "occupation";
                    str = obj[j].occupation;
                    break;
                case 4:
                    head = "relationship";
                    str = obj[j].relationship;
                    break;
                case 5:
                    head = "race";
                    str = obj[j].race;
                    break;
                case 6:
                    head = "sex";
                    str = obj[j].sex;
                    break;
                case 7:
                    head = "native-country";
                    str = obj[j].country;
                    break;
                case 8:
                    head = "age";
                    str = String.valueOf(obj[j].age);
                    break;
                case 9:
                    head = "hours-per-week";
                    str = String.valueOf(obj[j].hoursperweek);
                    break;
                case 10:
                    head = "capital-Gain";
                    str = String.valueOf(obj[j].capital_gain);
                    break;
                case 11:
                    head = "capital-Loss";
                    str = String.valueOf(obj[j].capital_loss);
                    break;
                case 12:
                    head = "education-num";
                    str = String.valueOf(obj[j].edu_num);
                    break;
                default:
                    break;
            }
            
            if(alist.contains(str))
                temp = alist.indexOf(str);
            else
            {
                alist.add(str);
                temp = alist.indexOf(str);
            }
                    
            
            if(obj[j].incomeclass.equals(">50K"))
                g50[temp]++;
            
            total[temp]++;
            
            
        }
        size = alist.size();
        for(int k=0;k<size;k++)
        {
            
           int l = total[k]-g50[k];
//           System.out.println("<=50 "+l+" total = "+total[k]);
           double temp2;
           if(total[k]==g50[k] || total[k]==l)
               temp2 = 0.0;
           else if(g50[k]==l)
               temp2 = 1.0;
           else
               temp2 = -(((double)g50[k]/total[k])*log2((double)g50[k]/total[k]) + ((double)l/total[k])*log2((double)l/total[k]));
//           System.out.println(temp2);
           newe = newe + (((double)total[k]/num)*temp2);
        }
        
        double totalgain = olde - newe;
        System.out.println(head + " = "+totalgain);
        alist.clear();
        }
    }
}

class PrivacyChoice implements constants
{
    void randomalloc(Data[] obj){
        for(int i=0;i<num;i++)
        {
            obj[i].agech = (int) (2*Math.random());
            obj[i].cgainch = (int) (2*Math.random());
            obj[i].clossch = (int) (2*Math.random());
            obj[i].educh = (int) (2*Math.random());
            obj[i].hpwch = (int) (2*Math.random());
//          System.out.println(obj[i].agech+" "+obj[i].cgainch+" "+obj[i].educh+" "+obj[i].hpwch+" "+obj[i].clossch);
        }
        
    }
}

class WriteCSV implements constants
{
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";
    
    public static String FileHeader = "age,age-ch,education-num,education-ch,capital-gain,capital-gain-ch,capital-loss,capital-loss-ch,hours-per-week,hpwch";
    
    public void writeCSVfile(Data[] obj, String FileName)
    {
        FileWriter fw;
        try {
            fw = new FileWriter(FileName);
            
            fw.append(FileHeader.toString());
            fw.append(NEW_LINE_SEPARATOR);
            
            for(int i=0;i<num;i++)
            {
                fw.append(String.valueOf(obj[i].age));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].agech));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].edu_num));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].educh));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].capital_gain));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].cgainch));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].capital_loss));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].clossch));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].hoursperweek));
                fw.append(COMMA_DELIMITER);
                fw.append(String.valueOf(obj[i].hpwch));
                fw.append(NEW_LINE_SEPARATOR);
            }
            
        } catch (IOException ex) {
            Logger.getLogger(WriteCSV.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println("CSV File Created Succesfully");
    }
}

public class DataProject implements constants {
    
        
    public static void main(String[] args)throws Exception {
        
        Data [] person = new Data[num];
        
        
        ReadCSV.readCVS(person);
//        for(int j=0;j<num;j++)
//            System.out.println(person[j].age+person[j].workclass);

        System.out.println("Finding Information gain");
        InfoGain ig = new InfoGain();
        ig.gain(person);
        
        PrivacyChoice pv = new PrivacyChoice();
        pv.randomalloc(person);
        
        WriteCSV file = new WriteCSV();
        file.writeCSVfile(person, "C:\\Users\\My PC\\Desktop\\project 101\\adults_final.csv");
    }
    
    
}
 
